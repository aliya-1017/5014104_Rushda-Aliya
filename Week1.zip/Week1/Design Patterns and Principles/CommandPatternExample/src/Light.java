public class Light {
    public void turnOn() {
        System.out.println("light is turned ON");
    }

    public void turnOff() {
        System.out.println("light is turned OFF");
    }
}
