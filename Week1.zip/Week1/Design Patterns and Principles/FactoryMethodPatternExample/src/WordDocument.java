public interface WordDocument extends Document {
    void formatText();
}
