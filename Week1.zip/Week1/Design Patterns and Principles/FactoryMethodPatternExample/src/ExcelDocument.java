public interface ExcelDocument extends Document {

    void createChart();

}
