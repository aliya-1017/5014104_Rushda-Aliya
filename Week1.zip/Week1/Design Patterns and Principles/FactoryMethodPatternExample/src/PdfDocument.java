public interface PdfDocument extends Document {
    void addBookmark();
}
