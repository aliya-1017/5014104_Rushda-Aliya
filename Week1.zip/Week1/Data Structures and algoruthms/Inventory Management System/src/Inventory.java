import java.util.HashMap;
class Inventory {
    private HashMap<String, Product> productMap;

    public Inventory() {
        productMap = new HashMap<>();
    }

    public void addProduct(Product product) {
        productMap.put(product.getProductId(), product);
    }

    public void updateProduct(Product product) {
        if (productMap.containsKey(product.getProductId())) {
            productMap.put(product.getProductId(), product);
        } else {
            System.out.println("Product not found.\n");
        }
    }

    public void deleteProduct(String productId) {
        productMap.remove(productId);
    }

    public void printInventory() {
        for (Product product : productMap.values()) {
            System.out.println("Product ID: " + product.getProductId() + ", Name: " + product.getProductName() +
                    ", Quantity: " + product.getQuantity() + ", Price: " + product.getPrice());
        }
        System.out.println();
    }
}
