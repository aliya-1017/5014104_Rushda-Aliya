public class Main {
    public static void main(String[] args) {
        Inventory inventory = new Inventory();
        Product product1 = new Product("1", "Apple", 10, 100.0);
        Product product2 = new Product("2", "Mango", 20, 200.0);
        Product product3 = new Product("3", "Banana", 20, 200.0);

        //adding the above 3 products to the inventory
        inventory.addProduct(product1);
        inventory.addProduct(product2);
        inventory.addProduct(product3);
        inventory.printInventory();

        //updating the price of apple
        product1.setPrice(120.0);
        inventory.updateProduct(product1);
        inventory.printInventory();

        //updating the product3 details
        product3.setProductName("Kiwi");
        product3.setQuantity(5);
        inventory.updateProduct(product3);
        inventory.printInventory();

        //deleting mango from the inventory
        inventory.deleteProduct("2");
        inventory.printInventory();
    }
}