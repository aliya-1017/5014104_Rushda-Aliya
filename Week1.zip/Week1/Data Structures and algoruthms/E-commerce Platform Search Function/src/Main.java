import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create an array of products
        Product[] products = {
                new Product("1", "Smartwatch", "Electronics"),
                new Product("2", "Headphones", "Electronics"),
                new Product("3", "Jacket", "Clothing"),
                new Product("4", "Sofa", "Furniture"),
                new Product("5", "Bookshelf", "Furniture")
        };

        // Enter the product name
        System.out.print("Enter the product name: ");
        String productNameInput = scanner.nextLine();

        boolean found = false;

        // Linear search by product name
        int indexByNameLinear = SearchFunction.linearSearchByName(products, productNameInput);
        if (indexByNameLinear != -1) {
            System.out.println("Linear Search by Name: Product ID: " + products[indexByNameLinear].getProductId()+", Category type: "+products[indexByNameLinear].getCategory());
            found = true;
        } else {
            System.out.println("Product not found by linear search.");
        }

        // Binary search by product name
        Arrays.sort(products, (p1, p2) -> p1.getProductName().compareTo(p2.getProductName()));
        int indexByNameBinary = SearchFunction.binarySearchByName(products, productNameInput);
        if (indexByNameBinary != -1) {
            System.out.println("Binary Search by Name: Product ID: " + products[indexByNameBinary].getProductId()+", Category type: "+products[indexByNameBinary].getCategory());
            found = true;
        } else {
            System.out.println("Product not found by binary search.");
        }

        // If the user written wrong spelling in that case we can search by ID
        if (!found) {
            System.out.println("\nProceeding to search by product ID.");

            System.out.print("Enter the product ID: ");
            String productIdInput = scanner.nextLine();

            //linear search by product ID
            int indexByIdLinear = SearchFunction.linearSearchById(products, productIdInput);
            if (indexByIdLinear != -1) {
                System.out.println("Linear Search by ID: Product name: "+ products[indexByIdLinear].getProductName()+", Category type: "+products[indexByIdLinear].getCategory());
                found = true;
            } else {
                System.out.println("Product ID not found by linear search.");
            }

            //Binary search by product ID
            Arrays.sort(products, (p1, p2) -> p1.getProductId().compareTo(p2.getProductId()));
            int indexByIdBinary = SearchFunction.binarySearchById(products, productIdInput);
            if (indexByIdBinary != -1) {
                System.out.println("Binary Search by ID result: Product name: " + products[indexByIdBinary].getProductName()+", Category type: "+products[indexByIdBinary].getCategory());
                found = true;
            } else {
                System.out.println("Product ID not found by binary search.");
            }

            if (!found) {
                System.out.println("Product not found.");
            }
        }
    }
}
