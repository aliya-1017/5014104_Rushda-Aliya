import java.util.Arrays;

public class SearchFunction {

    // Linear search by product name
    public static int linearSearchByName(Product[] products, String productName) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductName().equals(productName)) {
                return i;
            }
        }
        return -1;
    }

    // Binary search by product name
    public static int binarySearchByName(Product[] products, String productName) {
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int result = products[mid].getProductName().compareTo(productName);
            if (result == 0)
                return mid;
            if (result < 0)
                left = mid + 1;
            else
                right = mid - 1;
        }
        return -1;
    }

    // Linear search by product ID
    public static int linearSearchById(Product[] products, String productId) {
        for (int i = 0; i < products.length; i++) {
            if (products[i].getProductId().equals(productId)) {
                return i;
            }
        }
        return -1;
    }

    // Binary search by product ID
    public static int binarySearchById(Product[] products, String productId) {
        int left = 0, right = products.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int result = products[mid].getProductId().compareTo(productId);
            if (result == 0)
                return mid;
            if (result < 0)
                left = mid + 1;
            else
                right = mid - 1;
        }
        return -1;
    }
}
