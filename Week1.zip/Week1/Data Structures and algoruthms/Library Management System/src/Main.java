public class Main {
    public static void main(String[] args) {
        Book[] books = {
                new Book("1", "Effective Java", "Joshua Bloch"),
                new Book("2", "Clean Code", "Robert C. Martin"),
                new Book("3", "Design Patterns", "Erich Gamma")
        };

        System.out.println("Linear Search result:\nBook ID is: " + LibraryManagement.linearSearch(books, "Clean Code"));
        System.out.println("Binary Search result:\nBook ID is:  " + LibraryManagement.binarySearch(books, "Design Patterns"));
    }
}
