public class LibraryManagement {
    public static int linearSearch(Book[] books, String title) {
        for (int i = 0; i < books.length; i++) {
            if (books[i].getTitle().equals(title)) {
                return i;
            }
        }
        return -1;
    }

    public static int binarySearch(Book[] books, String title) {
        int left = 0, right = books.length - 1;
        while (left <= right) {
            int mid = left + (right - left) / 2;
            int result = books[mid].getTitle().compareTo(title);
            if (result == 0)
                return mid;
            if (result < 0)
                left = mid + 1;
            else
                right = mid - 1;
        }
        return -1;
    }
}
