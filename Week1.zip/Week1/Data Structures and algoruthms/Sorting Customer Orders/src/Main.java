public class Main {
    public static void main(String[] args) {
        Order[] orders = {
                new Order("1", "Harry", 300.50),
                new Order("2", "John", 155.45),
                new Order("3", "Sara", 79)
        };

        // Bubble Sort
        BubbleSort.bubbleSort(orders);
        System.out.println("Orders sorted by Bubble Sort:");
        for (Order order : orders) {
            System.out.println(order.getCustomerName() + ": " + order.getTotalPrice());
        }
        System.out.println();

        //Quick sort
        QuickSort.quickSort(orders, 0, orders.length - 1);
        System.out.println("Orders sorted by Quick Sort:");
        for (Order order : orders) {
            System.out.println(order.getCustomerName() + ": " + order.getTotalPrice());
        }
    }
}
