public class Main {
    public static void main(String[] args) {
        TaskManagement tms = new TaskManagement();

        //add task
        tms.addTask(new Task("1", "Yoga", "Pending"));
        tms.addTask(new Task("2", "Book Reading", "Completed"));

        //traverse task
        tms.traverseTasks();

        //search task
        Task task = tms.searchTask("1");
        if (task != null) {
            System.out.println("Found Task: " + task.getTaskName());
        } else {
            System.out.println("Task not found.");
        }

        //delete task
        tms.deleteTask("2");
        tms.traverseTasks();
    }
}
