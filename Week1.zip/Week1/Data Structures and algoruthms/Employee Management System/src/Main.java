public class Main {
    public static void main(String[] args) {
        EmployeeManagementSystem ems = new EmployeeManagementSystem(5);

        //adding employees
        ems.addEmployee(new Employee("1", "Aliya", "Developer", 60000));
        ems.addEmployee(new Employee("2", "Rahul", "Manager", 55000));

        ems.traverseEmployees();

        //searching employee
        Employee emp = ems.searchEmployee("1");
        if (emp != null) {
            System.out.println("\nEmployee name: " + emp.getName()+"\n");
        } else {
            System.out.println("Employee not found.");
        }

        //delete employee
        ems.deleteEmployee("2");
        ems.traverseEmployees();
    }
}
