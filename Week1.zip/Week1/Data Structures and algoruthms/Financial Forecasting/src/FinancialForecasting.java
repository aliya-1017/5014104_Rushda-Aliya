public class FinancialForecasting {
    public static double predictFutureValue(double currentValue, double growthRate, int periods) {
        if (periods == 0) {
            return currentValue;
        }
        return (1 + growthRate) * predictFutureValue(currentValue, growthRate, periods - 1);
    }
}
