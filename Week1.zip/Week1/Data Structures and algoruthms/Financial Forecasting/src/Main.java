public class Main {
    public static void main(String[] args) {
        double currentValue = 2200;
        double growthRate = 0.05;
        int periods = 8;

        double futureValue = FinancialForecasting.predictFutureValue(currentValue, growthRate, periods);
        System.out.println("Future Value: " + futureValue);
    }
}
